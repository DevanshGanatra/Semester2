public class LargestPrimeNo{
    public static void main(String[] args) {
        int start=1008;
        int end=9008;
        for(int i=2; i<=(start)/2;i++)
        {
            
        }
    }
}