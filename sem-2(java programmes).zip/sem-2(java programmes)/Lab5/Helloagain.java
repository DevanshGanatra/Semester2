public class Helloagain{
    public static void main(String[] args){
        System.out.println("Hello I m Coding.");
    }
}