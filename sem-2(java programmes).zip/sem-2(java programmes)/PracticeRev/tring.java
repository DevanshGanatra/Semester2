import java.util.*;

public class tring {
   public static void main(String[] args)
   {





   } 
}
