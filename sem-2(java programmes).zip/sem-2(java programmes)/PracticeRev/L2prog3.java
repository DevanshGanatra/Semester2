import java.util.Scanner;

public class L2prog3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 2 Inegers And enter operator that you want to perform");
        double a=sc.nextDouble();
        double b=sc.nextDouble();
        char operator=sc.next().charAt(0);
        switch (operator) {
                case '+':
                System.out.println(a+b);
                break;
                case '-':
                System.out.println(a-b);
                break;    
                case '*':
                System.out.println(a*b);
                break; 
                case '/':
                System.out.println(a/b);
                break;
            default:
                System.out.println("Invalid Operator");
                break;
        }

    }
}
