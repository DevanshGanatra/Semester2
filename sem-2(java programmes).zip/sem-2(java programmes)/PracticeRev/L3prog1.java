import java.util.Scanner;

public class L3prog1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Marks of Five Subjects");
        int a1=sc.nextInt();
        int a2=sc.nextInt();
        int a3=sc.nextInt();
        int a4=sc.nextInt();
        int a5=sc.nextInt();
        double percentage=(a1+a2+a3+a4+a5)/5.0;
        if(percentage>=60)
        System.out.println("First Division");
        else if (percentage>=50)
        System.out.println("Second Division");
        else if (percentage>=40)
        System.out.println("Third Division");
        else
        System.out.println("Fail");
        
    }
}
