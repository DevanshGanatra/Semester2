import java.util.Scanner;

public class pptbinarysort {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int[] myarray={2,3,5,6,8,9,11,18,29,65};
       for(int element: myarray)
       {
        System.out.println(element);
       }
    }
}