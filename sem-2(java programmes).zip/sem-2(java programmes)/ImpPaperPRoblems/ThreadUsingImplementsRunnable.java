
class MyThread implements Runnable{
    public void run(){
        try {
            for(int i=1;i<=5;i++)
            {
                System.out.println("Thread is working Good Moorning: "+i);
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

public class ThreadUsingImplementsRunnable {
    public static void main(String[] args) {
        MyThread m1=new MyThread();
        Thread t1=new Thread(m1);
        t1.start();
        for(int i=1;i<=5;i++)
        {
            System.out.println("Main Thread is working Good Moorning: "+i);
        }
    }
}
