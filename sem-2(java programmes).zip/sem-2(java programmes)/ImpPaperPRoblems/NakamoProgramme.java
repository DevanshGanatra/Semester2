/*WAP to print if a number is zero or positive or negative */

import java.util.Scanner;

public class NakamoProgramme {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter any integer:");
        int a = sc.nextInt();
        if (a >= 0) {
            if (a > 0) {
                System.out.println("positiive");
            } else {
                System.out.println("Zero");
            }
        } else {
            System.out.println("Negative");
        }

    }
}
