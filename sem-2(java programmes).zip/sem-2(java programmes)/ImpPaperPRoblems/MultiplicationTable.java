/*WAP to print multiplication table  */

import java.util.Scanner;

public class MultiplicationTable {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Integer:");
        int संख्या =sc.nextInt();
        for(int i=1;i<=10;i++)
        {
            System.out.println(संख्या +"*"+i+"="+(संख्या *i));
        }
        sc.close();
    }
}
