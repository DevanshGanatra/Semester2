/*Write a program to check whether given word is palindrome or not. */

import java.util.Scanner;

public class PallindromeOrNot {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter any Word: ");
        String word = sc.nextLine().toLowerCase();
        boolean isPallindrome = true;
        for (int i = 0; i < word.length() / 2; i++) {
            if (word.charAt(i) != (word.charAt(word.length() - 1 - i))) {
                isPallindrome = false;
                break;
            }
        }
        if (isPallindrome) {
            System.out.println("Its Pallindrome");
        } else {
            System.out.println("Its not");
        }

    }
}
