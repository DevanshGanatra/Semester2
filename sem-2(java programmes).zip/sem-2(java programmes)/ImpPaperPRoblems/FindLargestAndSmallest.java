/*WAP to find largest and smallest from an array.  */

import java.util.Scanner;

public class FindLargestAndSmallest {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter array size: ");
        int arrsize=sc.nextInt();
        int numbers[]=new int[arrsize];
        System.out.println("Enter Integers: ");
        numbers[0]=sc.nextInt();
        int smallest=numbers[0];
        int largest=numbers[0];
        for(int i=1;i<=arrsize;i++)
        {
            System.out.println("Enter Integers: ");
            numbers[i]=sc.nextInt();
            if(numbers[i]<smallest)
            {
                smallest=numbers[i];
            }
            if(numbers[i]>largest)
            {
                smallest=numbers[i];
            }
        }
        System.out.println("Largest integr: "+largest);
        System.out.println("Smallest integer: "+smallest);
    }
}
