import java.util.Scanner;

class Game{
    void type()
    {
        System.out.println("Ramat");
    }
}
class Cricket{
    void type()
    {
        System.out.println("Kricket");
    }
}   
class Football{
    void type(){
        System.out.println("PAG DADO");
    }
}


public class DynamicMethodDispatch {
    public static void main(String[] args) {
        Game g=new Game();
        Cricket c=new Cricket();
        Football f=new Football();
        System.out.println("Enter game:");
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        if(s.equals("Cricket"))
        {
            c.type();
        }
        else if(s.equals("Football"))
        {
            f.type();
        }
        else if(s.equals("Game"))
        {
            g.type();
        }
    }
}
