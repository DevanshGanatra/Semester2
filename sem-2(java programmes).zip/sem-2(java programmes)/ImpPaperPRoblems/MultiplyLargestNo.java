/*Write a program to multiply largest number (among two) with ‘50’ using conditional operator.  */
import java.util.*;
public class MultiplyLargestNo {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter two No:");
        int a=sc.nextInt();
        int b=sc.nextInt();
        int temp=a>b?(temp=a*50):(temp=b*50);
        System.out.println(temp);
    }
}