/*Implement a two dimensional array named 'marks' and initialize it.  */

import java.util.Scanner;

public class TwoDArray {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int[][] marks = {
            {80, 75, 90},   // Marks for student 1
            {85, 65, 70},   // Marks for student 2
            {90, 95, 85},   // Marks for student 3
            {70, 60, 80}    // Marks for student 4
        };
    }
}
