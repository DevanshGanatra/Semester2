/*Write a program that calculates and prints the sum of the even integers from 1 to 100 */
public class Sumofeven1to100 {
    public static void main(String[] args) {
        int sum=0;
        for(int i=2;i<=100;i=i+2){
            sum+=i;
        }
        System.out.println("sum of the even integers from 1 to 100 is :"+sum);
    }
}
