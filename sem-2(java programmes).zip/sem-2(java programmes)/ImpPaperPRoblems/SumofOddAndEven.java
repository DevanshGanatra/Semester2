/*WAP to calculate sum of odd and even elements of an array */

import java.util.Scanner;

public class SumofOddAndEven {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter array size: ");
        int arrsize = sc.nextInt();
        int oddsum=0,evensum=0;
        int numbers[] = new int[arrsize];
        for(int i=0;i<arrsize;i++)
        {
            System.out.println("Enter Integers: ");
            numbers[i]=sc.nextInt();
            if(numbers[i] %2==0)
            {
                evensum+=numbers[i];
            }
            else
            {
                oddsum+=numbers[i];
            }
        }
        System.out.println("odd sum= "+oddsum);
        System.out.println("even sum= "+evensum);
    }
}
