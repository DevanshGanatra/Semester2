/*WAP to count positive number, negative number and zero from an array of n size  */

import java.util.Scanner;

public class CountPosNegZero {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter size of Array:");
        int size = sc.nextInt();
        int zero = 0, pos = 0, neg = 0;
        int num[] = new int[size];
        for (int i = 0; i < size; i++) {
            System.out.println("Enter Integer: ");
            num[i] = sc.nextInt();
            if (num[i] == 0) {
                zero++;
            }
            if (num[i] > 0) {
                pos++;
            }
            if (num[i] < 0) {
                neg--;
            }
        }
        System.out.println("No of zeros: " + zero);
        System.out.println("no of positives: " + pos);
        System.out.println("no of negatives: " + neg);
    }
}