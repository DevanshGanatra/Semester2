/*Write a function to search a given number from an array. */

import java.util.Scanner;

class Search {
    void toSearch(int numberarray[], int num) {
        int temp = 0;
        for (int i = 0; i < numberarray.length; i++) {
            if (num == numberarray[i]) {
                temp = 1;
                break;
            }
        }
        if (temp == 1) {
            System.out.println("Number " + num + " is found");
        } else {
            System.out.println("number " + num + " is not found");
        }
    }
}

public class SearchElementFromArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numberarray[] = { 10, 9, 8, 7, 5, 6, 4, 2, 35, 4, 8, 5, 4, 556, 9, 582, 262, 5, 584, 25, 266, 2, 10 };
        System.out.println("enter integer to find:");
        int num = sc.nextInt();
        Search s1 = new Search();
        s1.toSearch(numberarray, num);
    }
}
