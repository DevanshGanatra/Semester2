/*Write a menu driven program that allows user to enters five numbers and then choose between finding the smallest,
 largest, sum or average. Use switch case to determine what action to take.
  Provide error message if an invalid choice is entered */

import java.util.Scanner;

public class SwitchCaseProblem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a[] = new int[5];
        double avg = 0;
        System.out.println("Enter Integer-1:");
        a[0] = sc.nextInt();
        int sum = a[0];
        int smallest = a[0];
        int largest = a[0];
        for (int i = 1; i < 5; i++) {
            System.out.println("Enter Integer-" + (i + 1) + ": ");
            a[i] = sc.nextInt();
            if (a[i] < smallest) {
                smallest = a[i];
            }
            if (a[i] > largest) {
                largest = a[i];
            }
            sum = sum + a[i];
        }
        avg = sum / 5.0;
        System.out.println("Enter 1 To Find Smalest No.: ");
        System.out.println("Enter 2 To Find Largest No.: ");
        System.out.println("Enter 3 to find sum: ");
        System.err.println("Enter 4 to find Avg: ");
        int temp = sc.nextInt();

        switch (temp) {
            case 1:
                System.out.println("Smallest:" + smallest);
                break;
            case 2:
                System.out.println("Largest:" + largest);
                break;
            case 3:
                System.out.println("Sum:" + sum);
                break;
            case 4:
                System.out.println("Avg:" + avg);
                break;
            default:
                System.out.println("Invalid Input");
                break;
        }
    }
}
