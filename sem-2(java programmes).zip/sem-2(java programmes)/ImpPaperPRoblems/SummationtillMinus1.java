/*WAP to calculate the sum of given numbers, enter -1 to terminate.  */

import java.util.Scanner;

public class SummationtillMinus1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = 0;
        int sum = 0;
        while (a != -1) {
            System.out.println("Enter Integer other than -1 (or enter -1 to terminate): ");
            a = sc.nextInt();
            if (a != -1) {
                sum += a;
            }
        }
        System.out.println("Sum= " + sum);
    }
}
