import java.util.Scanner;

class MyException extends Exception{
    public MyException(String s)
    {
        super(s);
    }
}


public class CustomExcepion {
    public static void main(String[] args) {
        try{
            int currentBalance=5000;
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter Withdraw Amount:");
            int Withdraw=sc.nextInt();
            if(Withdraw>currentBalance)
            {
                throw new MyException("Withdraw Amount cant be greater than Current Balance");
            }
            else{
                System.out.println("Amount withdrawed: "+Withdraw);
                currentBalance=currentBalance-Withdraw;
                System.out.println("Current balance: "+currentBalance);
            }
        }
       catch(Exception e)
       {
        e.printStackTrace();
       }
    }
}
