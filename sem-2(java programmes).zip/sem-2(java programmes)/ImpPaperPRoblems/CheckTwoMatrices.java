/*Java Array Program to Check Whether Two Matrices Are Equal or Not */
import java.util.*;
public class CheckTwoMatrices {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int matrix1[][]={
                            {1,2,3},
                            {4,5,6},
                            {7,8,9}   
        };
        int matrix2[][]={
                            {1,2,3},
                            {4,5,6},
                            {7,8,9}
        };
        
    }
}
