/*Any year is entered through the keyboard, write a program to determine whether the year is leap or not.  */
import java.util.*;
public class LeapYear {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter any year ");
        int year=sc.nextInt();
        if((year%4==0 && year%100!=0)||(year%400==0))
        {
            System.out.println("Its an Leap Year");
        }
        else{
            System.out.println("Its not");
        }
    }
}
