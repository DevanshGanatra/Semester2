
class MyThread extends Thread{
    @Override
    public void run(){
        try{
            for(int i=1;i<=5;i++)
            {
                System.out.println("Thread is working Good Moorning: "+i);
                Thread.sleep(1000);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
      
    }
}



public class ThreadUsingExtendsThread {
    public static void main(String[] args) {
        MyThread th=new MyThread();
        th.start();
        for(int i=1;i<=5;i++)
        {
            System.out.println("Main Thread is working Good Moorning: "+i);
        }
    }
}
