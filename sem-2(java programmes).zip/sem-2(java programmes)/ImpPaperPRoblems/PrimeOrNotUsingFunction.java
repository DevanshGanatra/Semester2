/*Write a function to check whether given number is prime or not.  */

import java.util.Scanner;

class Check {
    void IsPrime(int num) {
        int temp = 0;
        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) {
                temp = 1;
                break;
            }
        }
        if (temp == 1) {
            System.out.println("Its Not Prime");
        } else {
            System.out.println("Its Prime");
        }
    }
}

public class PrimeOrNotUsingFunction {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Any integer:");
        int num=sc.nextInt();
        Check c1=new Check();
        c1.IsPrime(num);
        sc.close();
    }
}