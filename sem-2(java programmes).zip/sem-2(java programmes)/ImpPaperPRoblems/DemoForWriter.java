import java.io.FileWriter;
import java.io.Writer;

public class DemoForWriter {
    public static void main(String[] args) {
        try {
            Writer wr=new FileWriter("AbcWRITER.txt");
            wr.write("HEllo Bhai chal chai pila");
            wr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
