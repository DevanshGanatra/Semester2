/*WAP to print factors of a given number */

import java.util.Scanner;

public class Factors {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter any Integer:");
        int n=sc.nextInt();
        sc.close();
        for(int i=1;i<=n;i++)
        {
            if(n%i==0)
            {
                System.out.println(i+" is a factor");
            }
        }
    }
}
