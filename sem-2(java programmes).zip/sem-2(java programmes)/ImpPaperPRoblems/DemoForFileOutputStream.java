import java.io.FileOutputStream;
public class DemoForFileOutputStream {
    public static void main(String[] args) {
        try{
            FileOutputStream fos = new FileOutputStream("abc.txt");
            String s="Hello World";
            byte b[]=s.getBytes();
            fos.write(b);
            fos.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
    }
}
