import java.util.Scanner;

public class BinarySearch {
    public static void main(String[] args) {
        int Myarray[]={1,2,3,4,5,8,10,45,78,89,99};
        System.out.println("Enter Element to Find:");
        Scanner sc=new Scanner(System.in);
        int target=sc.nextInt();
        int right=Myarray.length-1;
        int left=0;
        boolean isFound=false;
        while (left<=right) {
            int mid=left +(right-left)/2;

            if(Myarray[mid]==target)
            {
                System.out.println("Elemnet is Found at: "+mid);
                isFound=true;
                break;
            }
            if(Myarray[mid]> target)
            {
                right=mid-1;
            }
            else{
                left=mid+1;
            }
        }
        if(isFound==false)
        {
            System.out.println("Element doesnt Found.");
        }
    }
}
