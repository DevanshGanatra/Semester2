/*WAP to perform addition of two 3 x 3 matrices */

import java.util.Scanner;

public class AdittionOf3x3Matrix {
    public static void main(String[] args) {
        int arr1[][] = new int[3][3];
        int arr2[][] = new int[3][3];
        int sum[][] = new int[3][3];
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Elements for Matrix one:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.println("Enter Integer for aar1[" + i + "][" + j + "]: ");
                arr1[i][j] = sc.nextInt();
            }
        }
        System.out.println();
        System.out.println("Enter Elements for Matrix two:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.println("Enter Integer for aar2[" + i + "][" + j + "]: ");
                arr2[i][j] = sc.nextInt();
                sum[i][j] = arr1[i][j] + arr2[i][j];
            }
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(sum[i][j] + " ");
            }
            System.out.println();
        }
    }
}
