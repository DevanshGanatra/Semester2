/*WAP to calculate sum and average of n numbers from an array */

import java.util.Scanner;

public class AvgOfNnumbers {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter size of array:");
        int size=sc.nextInt();
        int numberArray []=new int[size];
        int sum=0;
        double avg=0;
        for(int i=0;i<size;i++)
        {
            System.out.println("Enter Integer: ");
            numberArray[i]=sc.nextInt();
            sum+=numberArray[i];
        }
        avg=(double)sum/size;
        System.out.println("Sum of numbers: "+sum);
        System.out.println("Avg of numbers: "+avg);
    }
}
