import java.io.FileReader;
import java.io.Reader;

public class DemoForReader {
    public static void main(String[] args) {
        try {
            Reader red=new FileReader("xyz.txt");
            int i=0;
            while ((i=red.read())!=-1) {
                System.out.print((char)i);
            }
            red.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
