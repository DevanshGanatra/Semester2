import java.util.Scanner;

class Student{
    int rollno;
    int  present;
    public Student(int rollno, int present)
    {

        this.rollno=rollno;
        this.present=present;
    } 

   
   
   
    
}
public class prog1 {
    public static void main(String[] args) {
        Student[] stu= new Student[1000];
        Scanner sc=new Scanner(System.in);


        for(int i=0;i<stu.length;i++)
        {
            System.out.println("Roll no. "+(i+101));
            int temp=sc.nextInt();
            if(temp==-1)
            {
               i= ((((i+101)/100)+1)*100)-101;
               continue;
            }
            else if(temp==-2)
            {
                break;
            }
            stu[i]=new Student(i+101,temp);
        }
        for(int i=0;i<stu.length;i++)
        {
            if(stu[i]!=null && stu[i].present==0){
                System.out.print(stu[i].rollno+",");
            }
        }
    }
    
}