// Write a program to get 2 numbers from the user and print the sum of two numbers using command line and Scanner class.
public class L2prog1A {
    public static void main(String[] args) {
        int a=Integer.parseInt(args[0]);
        int b=Integer.parseInt(args[1]);
        System.out.println("sum of "+a+" and "+b+"="+(a+b));
    }
}
